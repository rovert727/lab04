//
//  cellTeams.m
//  Lab04
//
//  Created by Jose Rodriguez on 22/06/16.
//  Copyright © 2016 Jose. All rights reserved.
//

#import "cellTeams.h"

@implementation cellTeams

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
