//
//  cellTeams.h
//  Lab04
//
//  Created by Jose Rodriguez on 22/06/16.
//  Copyright © 2016 Jose. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cellTeams : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imgTeam;

@property (strong, nonatomic) IBOutlet UILabel *lblName;
@end
